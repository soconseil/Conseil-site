---
title: "À propos"
---

Je suis **[Votre Nom]**, consultant avec X années d’expérience (PME, ETI, scale‑ups).

- **Approche :** pragmatique, franche, orientée résultat  
- **Mode d’intervention :** mission flash (1–4 semaines) ou accompagnement trimestriel  
- **Secteurs :** industriel, services B2B, retail, tech

📩 **Contact :** [vous@exemple.com](mailto:vous@exemple.com)