---
title: "Accueil"
---

Bienvenue ! J’accompagne les **PME & ETI** sur des missions **courtes et impactantes** :

- **Stratégie & Go‑to‑Market**  
- **Efficacité opérationnelle** (process, achats, supply)  
- **Transformation numérique** (outils simples, IA pragmatique)

👉 **Premier diagnostic de 30 min offert** — [contactez‑moi](mailto:vous@exemple.com).